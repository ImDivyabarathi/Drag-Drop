var totalDraggable = 0;
var totalBay = 0;
var j;
var i;
var isCorrectDrop = false;
var startPos;

$(document).ready(function () {
    $("#btn").off('click').click(function () {
        $(".startPage").hide();
        $(".firstPage").show();
        clickStartButton();
    })
});


var clickStartButton = function () {
    numberOfDraggable = document.getElementById("a").value;
    numberOfBay = document.getElementById("b").value;
    for (i = 1; i <= numberOfDraggable; i++) {
        $('#demo1').append('<div class="draggable_outer droppable" id=draggable_' + i + '></div>');
        $('#draggable_' + i).append('<div class="draggable" id="draggable_' + i + '">drop_' + i + '</div>');
        console.log('1. drag element is created');
    }

    for (j = 1; j <= numberOfBay; j++) {
        var temp2 = document.createElement("div");
        var t2 = document.createTextNode("Drop here");
        temp2.appendChild(t2);
        document.getElementById("demo2").append(temp2);
        temp2.setAttribute("id", "droppable_" + j);
        temp2.setAttribute("class", "droppable");
        console.log('2. drag element is created');
    }
    enableDragDrop();
}

var enableDragDrop = function () {

    $(".draggable").draggable({
        revert: "invalid",
        start: function (event, ui) {
            console.log("started the drag");
            startPos = ui.helper.position();
        },
        drag: function () {
            console.log("dragging");
            isCorrectDrop=false;
        },
        stop: function () {
            console.log("stopped drag");
            if(isCorrectDrop){
                console.log('okayy');
            }
            else{
                var x = startPos.left;
                var y = startPos.top;
                console.log(x+' '+y);

                $(this).data("uiDraggable").originalPosition = {
                    x: 0,
                    y: 0
                };
                return !event;
                console.log('okayy revert');
                
            }
        },

    });
    $(".droppable").droppable({
        accept: ".draggable",
        drop: function (event, ui) {
            $(ui.draggable).appendTo(this);
            $(ui.draggable).css({ "left": "10px", "top": "5px" });
            isCorrectDrop = true;
        }
    });
}