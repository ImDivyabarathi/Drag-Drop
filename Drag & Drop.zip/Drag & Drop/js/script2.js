var totalDraggable = 0;
var totalBay = 0;
var temp = document.getElementById("btn");
var temp2 = document.getElementById("demo1");
var temp3 = document.getElementById("demo2");

$(document).ready(function () {
    // $('#btn').off('click').on('click',clickStartButton);
    $("#btn").off('click').click(function () {
        $(".startPage").hide();
        $(".firstPage").show();
        clickStartButton();
    })
});


var clickStartButton = function () {
    numberOfDraggable = document.getElementById("a").value;
    numberOfBay = document.getElementById("b").value;
    var i = 1;
    while (i <= numberOfDraggable) {
        var para = document.createElement("div");
        var t = document.createTextNode("You can drag me. Try on!");
        para.appendChild(t);
        document.getElementById("demo1").append(para);
        document.getElementsByTagName("div")[i + 1].setAttribute("draggable", "true");
        document.getElementsByTagName("div")[i + 1].setAttribute("data-draggable", "item");
        console.log('2');
        i++;
    }
    for (let j = 1; j <= numberOfBay; j++) {
        var para1 = document.createElement("p");
        var t2 = document.createTextNode("Drop here");
        para1.appendChild(t2);
        document.getElementById("demo2").append(para1);
        document.getElementsByTagName("p")[j + 1].setAttribute("class", "dropBay"); 
        document.getElementsByTagName("p")[j + 1].setAttribute("data-draggable", "target");
        console.log('3');
    }


    enableDragDrop();
}

var enableDragDrop = function () {
        var item = null;
        document.addEventListener('dragstart', function (e) {
            item = e.target;
            e.dataTransfer.setData('text', '');

        }, false);
        document.addEventListener('dragover', function (e) {
            if (item) {
                e.preventDefault();
            }

        }, false);
        document.addEventListener('drop', function (e) {
            if (e.target.getAttribute('data-draggable') == 'target') {
                e.target.appendChild(item);
                e.preventDefault();
            }

        }, false);
        document.addEventListener('dragend', function (e) {
            item = null;
        }, false);
}
   








var totalDraggable = 0;
var totalBay = 0;

$(document).ready(function () {
    // $('#btn').off('click').on('click',clickStartButton);
    $("#btn").off('click').click(function () {
        $(".startPage").hide();
        $(".firstPage").show();
        clickStartButton();
    })
});


var clickStartButton = function () {
    numberOfDraggable = document.getElementById("a").value;
    numberOfBay = document.getElementById("b").value;
    var i = 1;
    while (i <= numberOfDraggable) {
        var para = document.createElement("div");
        var t = document.createTextNode("You can drag me. Try on " + i + " !");
        para.appendChild(t);
        document.getElementById("demo1").append(para);
        // document.getElementsByTagName("div")[i + 2].setAttribute("draggable", "true");
        // document.getElementsByTagName("div")[i + 2].setAttribute("data-draggable", "item");
        para.setAttribute("class", "draggable");
        console.log('2');
        i++;
    }
    for (let j = 1; j <= numberOfBay; j++) {
        var para1 = document.createElement("div");
        var t2 = document.createTextNode("Drop here");
        para1.appendChild(t2);
        document.getElementById("demo2").append(para1);
        // para1.setAttribute("data-draggable", "target");
        para1.setAttribute("class", "droppable");
        console.log('3');
    }
    enableDragDrop();
}

var enableDragDrop = function () {
    // var item;
    // document.addEventListener('dragstart', function (e) {
    //     item = e.target;
    //     // e.dataTransfer.setData('text', '');

    // }, false);
    // document.addEventListener('dragover', function (e) {
    //     if (item) {
    //         e.preventDefault();
    //     }

    // }, false);
    // document.addEventListener('drop', function (e) {
    //     if (e.target.getAttribute('data-draggable') == 'target') {
    //         e.target.appendChild(item);
    //         e.preventDefault();
    //     }

    // }, false);


    $(".draggable").draggable({
        start: function(event, ui) {
            console.log(event);   
              console.log(ui);    
        },
        revert: function (event, ui) {
            $(this).data("uiDraggable").originalPosition = {
                top: 0,
                left: 0
            };
            return !event;
        }
    });
    $(".droppable").droppable({

    });
}
